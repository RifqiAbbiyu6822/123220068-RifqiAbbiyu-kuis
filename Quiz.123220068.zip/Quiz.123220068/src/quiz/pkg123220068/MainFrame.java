package quiz.pkg123220068;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainFrame extends JFrame implements ActionListener {
    private JButton motorButton, mobilButton;

    public MainFrame() {
        setSize(300, 150);
        setLocationRelativeTo(null);

        motorButton = new JButton("Motor");
        mobilButton = new JButton("Mobil");

        JPanel panel1 = new JPanel();
        panel1.add(motorButton);
        panel1.add(mobilButton);

        add(panel1);

        motorButton.addActionListener(this);
        mobilButton.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == motorButton) {
            new DetailFrame("Motor").setVisible(true);
        } else if (e.getSource() == mobilButton) {
            new DetailFrame("Mobil").setVisible(true);
        }
        dispose(); // Close the main frame after selecting a vehicle
    }
}
