package quiz.pkg123220068;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class DetailFrame extends JFrame implements ActionListener {
    private JTextField nameField, phoneField, daysField;
    private JRadioButton[] vehicleRadioButtons;
    private ButtonGroup vehicleGroup;
    private JButton saveButton;

    private String name, phone, vehicle;
    private int days;
    private double price;
    private boolean isSaved = false;

    public DetailFrame(String vehicleType) {
        setTitle("Detail Penyewaan");
        setSize(350, 250);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(6, 2));
        
        // Komponen F2&F3
        nameField = new JTextField(20);
        phoneField = new JTextField(20);
        daysField = new JTextField(5);

        if (vehicleType.equals("Motor")) {
            vehicleRadioButtons = new JRadioButton[3];
            vehicleRadioButtons[0] = new JRadioButton("Honda Scoopy - Rp. 100,000.0/hari");
            vehicleRadioButtons[1] = new JRadioButton("Yamaha Nmax - Rp. 150,000.0/hari");
            vehicleRadioButtons[2] = new JRadioButton("Honda Revo - Rp. 50,000.0/hari");
        } else if (vehicleType.equals("Mobil")) {
            vehicleRadioButtons = new JRadioButton[3];
            vehicleRadioButtons[0] = new JRadioButton("Sedan Timor - Rp. 200,000.0/hari");
            vehicleRadioButtons[1] = new JRadioButton("Avanza 2019 - Rp. 300,000.0/hari");
            vehicleRadioButtons[2] = new JRadioButton("Truk Fuso - Rp. 1,000,000.0/hari");
        }

        vehicleGroup = new ButtonGroup();
        for (JRadioButton radioButton : vehicleRadioButtons) {
            vehicleGroup.add(radioButton);
        }

        saveButton = new JButton("Simpan");

        panel.add(new JLabel("Nama Penyewa:"));
        panel.add(nameField);
        panel.add(new JLabel("Nomor Telepon:"));
        panel.add(phoneField);
        panel.add(new JLabel("Jenis Kendaraan:"));
        for (JRadioButton radioButton : vehicleRadioButtons) {
            panel.add(radioButton);
        }
        panel.add(new JLabel("Jumlah Hari:"));
        panel.add(daysField);
        panel.add(new JLabel()); // Blank label for layout
        panel.add(saveButton);

        saveButton.addActionListener(this);

        add(panel);

        setVisible(true);
    }

    DetailFrame() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void actionPerformed(ActionEvent e) {
        if (!isSaved) {
            try {
                name = nameField.getText();
                phone = phoneField.getText();
                days = Integer.parseInt(daysField.getText());
                for (JRadioButton radioButton : vehicleRadioButtons) {
                    if (radioButton.isSelected()) {
                        vehicle = radioButton.getText().split(" - ")[0];
                        price = Double.parseDouble(radioButton.getText().split(" - ")[1].replace("Rp. ", "")
                                .replace("/hari", "").replace(",", ""));
                    }
                }
                new SummaryFrame(name, phone, vehicle, days, price);
                isSaved = true;
                saveButton.setVisible(false);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Kolom Hari Perlu Diisi!");
            }
        }
    }
}
