package quiz.pkg123220068;

import javax.swing.*;
import java.awt.*;

public class SummaryFrame extends JFrame {
    private JLabel nameLabel, phoneLabel, vehicleLabel, daysLabel, totalLabel;
    private JButton finishButton;

    public SummaryFrame(String name, String phone, String vehicle, int days, double price) {
        setTitle("Detail dan Total Harga");
        setSize(350, 250);
        setLocationRelativeTo(null);

        nameLabel = new JLabel("Nama Penyewa: " + name);
        phoneLabel = new JLabel("Nomor Telepon: " + phone);
        vehicleLabel = new JLabel("Jenis Kendaraan: " + vehicle + " (Rp. " + String.format("%.1f", price) + "/hari)");
        daysLabel = new JLabel("Jumlah Hari: " + days);
        totalLabel = new JLabel("Total Harga: Rp. " + String.format("%.1f", (days * price)));

        finishButton = new JButton("Selesai");

        JPanel panel = new JPanel(new GridLayout(6, 1));
        panel.add(nameLabel);
        panel.add(phoneLabel);
        panel.add(vehicleLabel);
        panel.add(daysLabel);
        panel.add(totalLabel);
        panel.add(finishButton);

        finishButton.addActionListener(e -> dispose());

        add(panel);

        setVisible(true);
    }
}
